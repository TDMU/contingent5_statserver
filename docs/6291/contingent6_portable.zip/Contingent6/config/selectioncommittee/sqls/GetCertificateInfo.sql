select list(GT.TITLE || ' = ' ||
  (
    select SPGM.MARK
    from SP_GET_MARKSTR(ECD.MARKID) SPGM
  ), ascii_char(13) || ascii_char(10))
from ENTRANT_CERT_DISCIPLINES ECD
inner join GUIDE_TREE GT
on (GT.NODEID = ECD.DISCIPINEID)
where ECD.CERTIFICATEID = 