select SS.COMPETITIONID, left(SS.COMPETITION, char_length(SS.COMPETITION) - 2) as COMPETITION
from
(
  select EC.COMPETITIONID,
  (
      iif(not EC.RECRUITINGID is null, GTREC.TITLE || '; ', '')
      || iif(not EC.SPECIALITYID is null, GSP.TITLE || '; ', '')
      || iif(not EC.EDUFORMID is null, GEF.TITLE || '; ', '')
      || iif(not EC.EDUBASISID is null, GEB.TITLE || '; ', '')
      || iif(not EC.ADD_COMPETITION_INFO is null, EC.ADD_COMPETITION_INFO || '; ', '')
      || iif(not EC.CONCOURSID is null, GCC.TITLE || '; ', '')
      || iif(not EC.COUNTRYTYPEID is null, GCT.TITLE || '; ', '')
  ) as COMPETITION
  from ENTRANCE_COMPETITION EC
  left join GUIDE_TREE GTREC
  on (GTREC.NODEID = EC.RECRUITINGID)
  left join GUIDE_TREE GSP
  on (GSP.NODEID = EC.SPECIALITYID)
  left join GUIDE_TREE GR
  on (GR.NODEID = EC.RECRUITINGID)
  left join GUIDE_TREE GEF
  on (GEF.NODEID = EC.EDUFORMID)
  left join GUIDE_TREE GEB
  on (GEB.NODEID = EC.EDUBASISID)
  left join GUIDE_TREE GCC
  on (GCC.NODEID = EC.CONCOURSID)
  left join GUIDE_TREE GCT
  on (GCT.NODEID = EC.COUNTRYTYPEID)
  where EC.ENTERYEAR = RDB$GET_CONTEXT('USER_SESSION', 'ENTRANCEYEAR')
  and EC.CALCULATE_CONCOURS = 1
  order by EC.PATH, EC.SORTORDER
) SS