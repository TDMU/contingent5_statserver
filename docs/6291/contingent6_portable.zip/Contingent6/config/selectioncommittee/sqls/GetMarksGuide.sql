execute block (MARKSYSTEMID D$INTEGER = :MARKSYSTEMID,
  RESULTKIND D$INTEGER = :RESULTKIND
  -- ����: 1 - �������������, 2-����. ������ �� ���������, 4 - ����� �� ���������
)
returns (
  IDS D$VARCHAR20000,
  MARKS D$VARCHAR20000
)
as
declare variable I D$INTEGER;
declare variable MINMARK D$INTEGER;
declare variable MAXMARK D$INTEGER;
declare variable COUNT_AFTER_POINT D$INTEGER;
declare variable MARKS_STEP D$INTEGER;
begin
  IDS = '';
  MARKS = '';

  if (bin_and(RESULTKIND, 3) > 0) then
  begin
    select list(VGT.NODEID, ascii_char(13) || ascii_char(10)),
      list(VGT.TITLE, ascii_char(13) || ascii_char(10))
    from V_GUIDE_TREE VGT
    where VGT.TYPE_NODE_KEY = 'T_ENTRANCE_MARK'
    and VGT.USE = 1
    and not exists (
      select * 
      from V_GUIDE_VALUES VGV 
      where VGV.NODEID = VGT.NODEID 
      and VGV.FIELDNAME = 'INTERVIEW' 
      and VGV.VALUEBOOL = iif(bin_and(:RESULTKIND, 1) = 1, 0, 1)
    )
    order by 1
    into :IDS, :MARKS;
  end

  if (bin_and(RESULTKIND, 4) > 0) then
  begin
    MINMARK = RDB$GET_CONTEXT('USER_SESSION', 'MINMARK_' || MARKSYSTEMID);
    MAXMARK = RDB$GET_CONTEXT('USER_SESSION', 'MAXMARK_' || MARKSYSTEMID);
    COUNT_AFTER_POINT = RDB$GET_CONTEXT('USER_SESSION', 'COUNT_AFTER_POINT_' || MARKSYSTEMID);
    MARKS_STEP = cast(power(10, 2 - COUNT_AFTER_POINT) as integer);
  
    I = MINMARK;
    while (I <= MAXMARK) do
    begin
      IDS = IDS || iif(I = MINMARK and IDS = '' , '',
        ascii_char(13) || ascii_char(10)) || I;
  
      MARKS = MARKS || iif(I = MINMARK and MARKS = '', '',
        ascii_char(13) || ascii_char(10)) ||
        (I / 100) ||
        trim(trailing '.' from '.' || trim(trailing '0' from mod(I, 100)));
  
      I = I + MARKS_STEP;
    end
  end

  suspend;
end