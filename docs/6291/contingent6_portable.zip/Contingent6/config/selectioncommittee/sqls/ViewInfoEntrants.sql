execute block (IN_COMPETITIONID integer = :COMPETITIONID, ACCOUNTTIME timestamp = :ACCOUNTTIME)
returns (
  ENTRANT_DOCID integer, 
  FIO varchar(70), 
  SUM_MARKID integer, 
  MARKID_PROFILE integer, 
  OUT_COMPETITIONID integer,
  FULL_INFO type of column ENTRANT_DOCS.FULL_INFO,
  OUTWAVE FIB$BOOLEAN
)
as
declare variable TEMP varchar(200);
declare variable CURRENTCATEGORYKEY d$varchar150;
declare variable EDUBASIS_KEY type of column GUIDE_TREE.NODE_KEY;
begin
  CURRENTCATEGORYKEY = RDB$GET_CONTEXT('USER_TRANSACTION','CURRENTCATEGORYKEY');

  select GT_EDUBASIS.NODE_KEY
  from ENTRANCE_COMPETITION EC
  inner join GUIDE_TREE GT_EDUBASIS
  on (GT_EDUBASIS.NODEID = EC.EDUBASISID)
  where EC.COMPETITIONID = :IN_COMPETITIONID
  into :EDUBASIS_KEY;

  
  for select ED.ENTRANT_DOCID, ED.COMPETITIONID,
    (
      select VLEMR.MARK_SUMID from V_LAST_ENTRANT_MARKS_ROW VLEMR
      where (VLEMR.ENTRANT_DOCID = ED.ENTRANT_DOCID)
      and (VLEMR.COMPETITIONID = ED.COMPETITIONID)
    ) as MARK_SUMID,
    (
      select P.VALUESTR from V_PERSON_HISTORY_ONDATE P
      where P.PERSONID = ED.PERSONID
      and P.FIELDNAME = 'FIO'
    ) as FIO,
    (
      select
        cast(list(lpad(iif(ER_SORTED.NAME_RULES starting with 'MARKID',
          (select decode(ER_SORTED.NAME_RULES,
              'MARKID1', VLEMR.MARKID1,
              'MARKID2', VLEMR.MARKID2,
              'MARKID3', VLEMR.MARKID3,
              'MARKID4', VLEMR.MARKID4
            )
            from V_LAST_ENTRANT_MARKS_ROW VLEMR
            where (VLEMR.ENTRANT_DOCID = ED.ENTRANT_DOCID)
            and (VLEMR.COMPETITIONID = ED.COMPETITIONID)
          ),
          coalesce(
          (
            select VPV.VALUEBOOL
            from V_PERSON_VALUES VPV
            where VPV.FIELDNAME = ER_SORTED.NAME_RULES
            and VPV.PERSONID = ED.PERSONID
            union
            select VECV.VALUEBOOL
            from V_ENTRANT_COMPETITION_VALUES VECV
            where VECV.FIELDNAME = ER_SORTED.NAME_RULES
            and VECV.ENTRANT_DOCID = ED.ENTRANT_DOCID
          )
        , 0)), 5, cast(' ' as char(5)))) as varchar(200)) as VAL
      from (
        select (select GT.FIELDNAME from GUIDE_FIELDS GT where GT.NODEID = ER.FIELDID) as NAME_RULES
        from ENTRANTS_RULES ER
        where ER.ENTRANCEYEAR = extract(year from ED.ENTERDATE)
             and ER.RULESTYPEID = (select GT.NODEID from GUIDE_TREE GT where GT.NODE_KEY = 'RULESTYPE_PRIVILEGE_ORDER')
        order by ER.ORDER_RULES
      ) ER_SORTED
     ),
     iif(:EDUBASIS_KEY = 'EDUBASIS_B' and coalesce(ED.OUTWAVEDATE, '31.12.2099') <= :ACCOUNTTIME, 1, 0) as OUTWAVE,
     (
        select sum(ET.MARKID)
        from V_LAST_ENTRANTS_MARKS ET
        inner join ENTRANT_DOCS ED1
        on ED1.ENTRANT_DOCID = ET.ENTRANT_DOCID
        inner join ENTRANCE_COMPETITION EC
        on EC.COMPETITIONID = ED.COMPETITIONID
        inner join ENTRANT_DISCIPLINES DE
        on (DE.ENTRANTDISCIPLINESID = EC.ENTRANTDISCIPLINESID)
        and (exists(select *
          from GUIDE_ALLOW_NODES GAN
          where GAN.NODEID = DE.DISCIPLINEID
          and GAN.ALLOWNODEID = ET.DISCIPLINEID
        ) or (DE.DISCIPLINEID = ET.DISCIPLINEID))
        where ET.ENTRANT_DOCID = ED.ENTRANT_DOCID
        and DE.PROFILE = 1
      ) as MARKID_PROFILE,
      ED.FULL_INFO
    from TEMP_FOR_TRANSACTION TID
    inner join ENTRANT_DOCS ED
    on (ED.ENTRANT_DOCID = TID.ID)
    order by @@SORTORDER@
    into :ENTRANT_DOCID, :OUT_COMPETITIONID, :SUM_MARKID, :FIO, :TEMP, :OUTWAVE,
      :MARKID_PROFILE, :FULL_INFO
  do
  begin
    suspend;
  end
  delete from TEMP_FOR_TRANSACTION;
end