select list(
 (
  select VGV.VALUEINT
  from V_GUIDE_VALUES VGV
  where VGV.NODEID = VGT.NODEID
  and VGV.FIELDNAME = 'EDEBO_ID'
) || '=' || VGT.TITLE, ascii_char(13) || ascii_char(10))
from V_GUIDE_TREE VGT
where VGT.TYPE_NODE_KEY = 'T_REQUEST_STATUS'
and VGT.USE = 1
--order by VGT.SORTORDER