select ID 
from SP_GEN_UID