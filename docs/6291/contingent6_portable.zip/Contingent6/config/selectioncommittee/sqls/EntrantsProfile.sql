execute block (IN_COMPETITIONID bigint = :COMPETITIONID, ACCOUNTTIME timestamp = :ACCOUNTTIME, CALCCOMPETITIONACCOUNTID bigint = :CALCCOMPETITIONACCOUNTID)
as
  declare ACCEPTEE smallint;
  declare FCOMPETITIONID bigint;
  declare ENTRANT_DOCID bigint;
  declare OUT_COMPETITIONID bigint;
begin
  for select ED.ENTRANT_DOCID, ED.COMPETITIONID
  from ENTRANT_DOCS ED
  inner join PERSONS P
  on P.PERSONID = ED.PERSONID
  inner join INFO_ENTRANTS IE
  on IE.PERSONID = P.PERSONID
  inner join V_LAST_ENTRANT_MARKS_ROW VLEM
  on VLEM.ENTRANT_DOCID = ED.ENTRANT_DOCID
     and VLEM.COMPETITIONID = ED.COMPETITIONID
  where   ((ED.RETURNDATE is Null) or (ED.RETURNDATE > :ACCOUNTTIME))
          and (@@ORIGINALDOCS%1=1@)
          and (@@PAYMENT%1=1@)
          and (ED.CATEGORY_PROFILE = 1)
          and (ED.COMPETITIONID = :IN_COMPETITIONID)
  into :ENTRANT_DOCID, :OUT_COMPETITIONID
  do
  begin
    select PROFILE_POSITIVE
    from SP_POSITIVE_TESTS (:ENTRANT_DOCID, :IN_COMPETITIONID)
    into :ACCEPTEE;
    if (not exists (select *
        from CA2ENTRANT C2A
        inner join COMPETITION_ACCOUNT CA
        on CA.COMPETITIONACCOUNTID = C2A.COMPETITIONACCOUNTID
        where (C2A.ENTRANT_DOCID = :ENTRANT_DOCID)
               and (C2A.ACCEPTEE = 1)
               and  (CA.CALCCOMPETITIONACCOUNTID = :CALCCOMPETITIONACCOUNTID))
               and ACCEPTEE = 1)
    then
    begin
      insert into TEMP_FOR_TRANSACTION(ID, ADD_INFO)
      values (:ENTRANT_DOCID, :OUT_COMPETITIONID);
    end
  end
  for select EC.COMPETITIONID
    from ENTRANCE_COMPETITION EC
    where EC.NEXTCOMPETITIONID = :IN_COMPETITIONID
  into :FCOMPETITIONID
  do
  begin
    for select ED.ENTRANT_DOCID, ED.COMPETITIONID
      from CA2ENTRANT C2A
      inner join COMPETITION_ACCOUNT CA
      on CA.COMPETITIONACCOUNTID = C2A.COMPETITIONACCOUNTID
      inner join ENTRANT_DOCS ED
      on ED.ENTRANT_DOCID = C2A.ENTRANT_DOCID
          and (ED.COMPETITIONID = C2A.COMPETITIONID)
      where ((ED.RETURNDATE is Null) or (ED.RETURNDATE > :ACCOUNTTIME))
            and (@@ORIGINALDOCS1%1=1@)
            and (@@PAYMENT1%1=1@)
            and (ED.CATEGORY_PROFILE = 1)
            and ( CA.COMPETITIONID = :FCOMPETITIONID)
            and (C2A.ACCEPTEE = 0)
            and (CA.CALCCOMPETITIONACCOUNTID = :CALCCOMPETITIONACCOUNTID)
    into :ENTRANT_DOCID, :OUT_COMPETITIONID
    do
    begin
      select PROFILE_POSITIVE
      from SP_POSITIVE_TESTS (:ENTRANT_DOCID, :OUT_COMPETITIONID)
      into :ACCEPTEE;
      if (ACCEPTEE = 1) then
      begin
        insert into TEMP_FOR_TRANSACTION(ID, ADD_INFO)
        values (:ENTRANT_DOCID, :OUT_COMPETITIONID);
      end
    end
  end
end