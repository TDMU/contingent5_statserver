execute block (TESTDATE date = :TESTDATE,
  DISCIPLINENUM smallint = :DISCIPLINENUM,
  UKRCERTIFICATE smallint = :UKRCERTIFICATE,
  NOCHECK smallint = :NOCHECK
)
returns (PERSONID bigint,
  FIO varchar(70),
  GROUPNUM varchar(10),
  ENTRANT_DOCID bigint,
  SPECIALITY varchar(100),
  EDUFORM varchar(20),
  EDUBASISID integer,
  EDUBASIS varchar(20),
  DISCIPLINE varchar(150),
  DISCIPLINEID integer,
  COMPETITIONID bigint,
  CALCCOMPETITIONID bigint
)
as
declare COMMON_FOR_CALC smallint;

declare CATEGORY_WOTESTS smallint;
declare CATEGORY_INTERVIEW smallint;
declare CATEGORY_PROFILE smallint;

declare TESTS_COUNT smallint;
declare PREV_TESTS_COUNT smallint;
declare PREV_POSITIVE_TESTS_COUNT smallint;
declare PROFILE_TESTS_COUNT smallint;
declare PREV_PROFILE_TESTS_COUNT smallint;
declare PROFILE_POSITIVE_TESTS_COUNT smallint;
declare INTERVIEW_TESTS_COUNT smallint;
declare INTERVIEW_POSITIVE_TESTS_COUNT smallint;
declare CUR_DISCIPLINE_TESTLIST_EXISTS smallint;
declare CUR_SERTIFICATE_EXISTS smallint;
declare INCLUDE_COMPETITION smallint;

begin
  for select VPHO.PERSONID,
         VPHO.VALUESTR as FIO,
         ED.GROUPNUM,
         ED.ENTRANT_DOCID,
         GS.TITLE as SPECIALITY,
         GE.TITLE as EDUFORM,
         EC.COMPETITIONID as CALCCOMPETITIONID,
         EDS.COMMON_FOR_CALC,
         GD.TITLE as DISCIPLINE,
         EM.DISCIPLINEID
      from ENTRANT_DOCS ED

      inner join TEMP_FOR_TRANSACTION TI
      on TI.ID = ED.ENTRANT_DOCID

      inner join V_PERSON_HISTORY_ONDATE VPHO
      on VPHO.PERSONID = ED.PERSONID
         and VPHO.FIELDNAME = 'FIO'
      inner join INFO_ENTRANTS IE
      on (IE.PERSONID = ED.PERSONID)

      inner join ENTRANCE_COMPETITION EC
      on EC.COMPETITIONID = (select EC1.CALCCOMPETITIONID
                            from ENTRANT_DOCS EDC
                            inner join ENTRANCE_COMPETITION EC1
                            on EC1.COMPETITIONID = EDC.COMPETITIONID
                            where EDC.ENTRANT_DOCID = ED.ENTRANT_DOCID)

      inner join ENTRANT_DISCIPLINES EDS
      on (EDS.ENTRANTDISCIPLINESID = EC.ENTRANTDISCIPLINESID)
      and (EDS.DISCIPLINENUM = :DISCIPLINENUM)

      inner join V_LAST_ENTRANTS_MARKS EM
      on (EM.ENTRANT_DOCID = ED.ENTRANT_DOCID)
         and (ec.COMPETITIONID = EM.COMPETITIONID)
         and (EM.DISCIPLINENUM = :DISCIPLINENUM)

      inner join GUIDE_TREE GS
      on GS.NODEID = EC.SPECIALITYID

      inner join GUIDE_TREE GE
      on GE.NODEID = EC.EDUFORMID

      inner join GUIDE_TREE GD
      on (GD.NODEID = EM.DISCIPLINEID)

      where ((ED.RETURNDATE is null) or (ED.RETURNDATE >= :TESTDATE))
      and (ED.ENTERDATE <= :TESTDATE)
      and ((coalesce(:UKRCERTIFICATE, -1) = -1) or (IE.UKRCERTIFICATE = :UKRCERTIFICATE))

      into :PERSONID, :FIO, :GROUPNUM, :ENTRANT_DOCID, :SPECIALITY, :EDUFORM,
           :CALCCOMPETITIONID, :COMMON_FOR_CALC, :DISCIPLINE, :DISCIPLINEID
  do
  begin
    INCLUDE_COMPETITION = 0;

    for select
        EDS_TEMP.COMPETITIONID,
        EDS_TEMP.CATEGORY_WOTESTS,
        EDS_TEMP.CATEGORY_INTERVIEW,
        EDS_TEMP.CATEGORY_PROFILE,
        sum(iif((ED.DISCIPLINENUM > 0), 1, 0)) as TESTS_COUNT,
        sum(iif((ED.DISCIPLINENUM between 1 and :DISCIPLINENUM - 1), 1, 0)) as PREV_TESTS_COUNT,
        sum(iif((ED.DISCIPLINENUM between 1 and :DISCIPLINENUM - 1) and (ET.MARKID > RDB$GET_CONTEXT('USER_SESSION', 'LIMIT2')), 1, 0)) as PREV_POSITIVE_TESTS_COUNT,
        sum(iif(ED.PROFILE = 1, 1, 0)) as PROFILE_TESTS_COUNT,
        sum(iif((ED.DISCIPLINENUM < :DISCIPLINENUM) and (ED.PROFILE = 1), 1, 0)) as PREV_PROFILE_TESTS_COUNT,
        sum(iif((ED.DISCIPLINENUM < :DISCIPLINENUM) and (ED.PROFILE = 1) and (ET.MARKID >= RDB$GET_CONTEXT('USER_SESSION', 'LIMIT5')), 1, 0)) as PROFILE_POSITIVE_TESTS_COUNT,
        sum(iif(ED.DISCIPLINENUM = 0, 1, 0)) as INTERVIEW_TESTS_COUNT,
        sum(iif((ED.DISCIPLINENUM = 0) and (ET.MARKID = -3), 1, 0)) as INTERVIEW_POSITIVE_TESTS_COUNT,
        sum(iif((ED.DISCIPLINENUM = :DISCIPLINENUM) and (not ET.TESTLISTID is null), 1, 0)) as CUR_DISCIPLINE_TESTLIST_EXISTS,
        sum(iif((ED.DISCIPLINENUM = :DISCIPLINENUM) and (ET.TESTLISTID is null) and (EM.MARKID >= 124), 1, 0)) as CUR_SERTIFICATE_EXISTS
      from ENTRANT_DOCS EDS_TEMP
      inner join ENTRANCE_COMPETITION EC
      on EC.COMPETITIONID = EDS_TEMP.COMPETITIONID
      inner join ENTRANT_DISCIPLINES ED
      on (ED.ENTRANTDISCIPLINESID = EC.ENTRANTDISCIPLINESID)
      left join ENTRANT_MARKS EM
      on EM.ENTRANT_DOCID = EDS_TEMP.ENTRANT_DOCID
        and EM.DISCIPLINENUM = ED.DISCIPLINENUM
      left join V_LAST_ENTRANTS_MARKS ET
      on (ET.ENTRANT_DOCID = EDS_TEMP.ENTRANT_DOCID)
      and (ET.DISCIPLINEID = ED.DISCIPLINEID)
      and (
        ((ED.COMMON_FOR_CALC = 1) and (ET.COMPETITIONID = (select EC1.CALCCOMPETITIONID
                                                         from ENTRANCE_COMPETITION EC1
                                                         where EC1.COMPETITIONID =  EDS_TEMP.COMPETITIONID)))
        or
        ((ED.COMMON_FOR_CALC = 0) and (ET.COMPETITIONID = EDS_TEMP.COMPETITIONID))
      )
      where (EDS_TEMP.ENTRANT_DOCID = :ENTRANT_DOCID)
      group by 1,2,3,4
      into :COMPETITIONID, :CATEGORY_WOTESTS, :CATEGORY_INTERVIEW, :CATEGORY_PROFILE,
           :TESTS_COUNT, :PREV_TESTS_COUNT, :PREV_POSITIVE_TESTS_COUNT, :PROFILE_TESTS_COUNT,
           :PREV_PROFILE_TESTS_COUNT, :PROFILE_POSITIVE_TESTS_COUNT,
           :INTERVIEW_TESTS_COUNT, :INTERVIEW_POSITIVE_TESTS_COUNT, :CUR_DISCIPLINE_TESTLIST_EXISTS,
           :CUR_SERTIFICATE_EXISTS
    do
    begin
      if (NOCHECK = 1) then
      begin
        INCLUDE_COMPETITION = 1;
      end
      else
      begin
        if (CUR_SERTIFICATE_EXISTS > 0) then INCLUDE_COMPETITION = 0;
        else
        if ((DISCIPLINENUM <= TESTS_COUNT)
           and (CATEGORY_WOTESTS = 0)
           and (CUR_DISCIPLINE_TESTLIST_EXISTS = 0)) then
        begin
          if (DISCIPLINENUM = 0) then
          begin
            if (CATEGORY_INTERVIEW = 1) then
            begin
              INCLUDE_COMPETITION = 1;
            end
          end
          else
          begin
            if (DISCIPLINENUM = 1) then
            begin
              if (CATEGORY_INTERVIEW = 0) then
              begin
                INCLUDE_COMPETITION = 1;
              end
              else
              begin
                if (INTERVIEW_POSITIVE_TESTS_COUNT <> INTERVIEW_TESTS_COUNT) then
                begin
                  INCLUDE_COMPETITION = 1;
                end
              end
            end
            else
            begin
              if (CATEGORY_PROFILE = 1) then
              begin
                if (not((PREV_PROFILE_TESTS_COUNT = PROFILE_TESTS_COUNT)
                      and (PROFILE_POSITIVE_TESTS_COUNT = PREV_PROFILE_TESTS_COUNT)
                      )) then
                begin
                  if (PREV_POSITIVE_TESTS_COUNT = PREV_TESTS_COUNT) then
                  begin
                    INCLUDE_COMPETITION = 1;
                  end
                end
              end
              else
              begin
                if (PREV_POSITIVE_TESTS_COUNT = PREV_TESTS_COUNT) then
                begin
                  INCLUDE_COMPETITION = 1;
                end
              end
            end
          end
        end
      end

      if (INCLUDE_COMPETITION > 0) then
      begin
        if (COMMON_FOR_CALC = 0) then
        begin
          INCLUDE_COMPETITION = 0;

          select EC.EDUBASISID, GEB.TITLE
          from ENTRANCE_COMPETITION EC
          inner join GUIDE_TREE GEB
          on (GEB.NODEID = EC.EDUBASISID)
          where EC.COMPETITIONID = :COMPETITIONID
          into :EDUBASISID, :EDUBASIS;

          suspend;
        end
        else
        begin
          break;
        end
      end
    end

    if ((COMMON_FOR_CALC = 1) and (INCLUDE_COMPETITION > 0)) then
    begin
      COMPETITIONID = CALCCOMPETITIONID;
      EDUBASISID = null;
      EDUBASIS = null;
      suspend;
    end
  end
end