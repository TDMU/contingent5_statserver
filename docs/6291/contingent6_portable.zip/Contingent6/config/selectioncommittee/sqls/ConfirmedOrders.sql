execute block (PARENTID bigint  = :PARENTID)
returns (NODEID bigint,
        TITLE varchar(150),
        HASCHILDREN smallint,
        IMAGEINDEX smallint)
as
begin
  if (coalesce(PARENTID, 0) = 0) then
  begin
    HASCHILDREN = 1;
    IMAGEINDEX = 34;

      for select distinct Extract(Year from O.ORDERDATE), Extract(Year from O.ORDERDATE)
        from ORDERS O
        order by 1 desc
        into :NODEID, :TITLE
    do
    begin
      suspend;
    end
  end
  else
  if (PARENTID < 9999) then
  begin
    HASCHILDREN = 1;
    IMAGEINDEX = 34;

      for select distinct Extract(Year from O.ORDERDATE) * 100000
  + O.DEPARTMENTID, GD.TITLE as DEPARTMENT
        from ORDERS O
        inner join GUIDE_TREE GD
        on (GD.NODEID = O.DEPARTMENTID)
        where Extract(Year from O.ORDERDATE) = :PARENTID
        order by GD.TITLE
        into :NODEID, :TITLE
    do
    begin
      suspend;
    end
  end
  else
  begin
    HASCHILDREN = 0;
    IMAGEINDEX = 36;

      for select O.ORDERID, ('� ' || O.ORDERNUM || ' �� ' || iif(Extract(Day from O.ORDERDATE) < 10, '0'||Extract(Day from O.ORDERDATE), Extract(Day from O.ORDERDATE))
       || '.' || iif(Extract(month from O.ORDERDATE) < 10
  , '0'||Extract(month from O.ORDERDATE), Extract(month from O.ORDERDATE)) || '.' || Extract(
  Year from O.ORDERDATE))
        from ORDERS O

          where Extract(Year from O.ORDERDATE) = cast(:PARENTID /
  100000 as integer)

          and O.DEPARTMENTID = :PARENTID - cast(:PARENTID / 100000
   as integer) * 100000
        order by O.ORDERDATE desc, O.ORDERNUM desc
        into :NODEID, :TITLE
    do
    begin
      suspend;
    end
  end
end