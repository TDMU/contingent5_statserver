select EC.COMPETITIONID, EC.CALCULATE_CONCOURS,
(
  select first 1 1
  from ENTRANCE_COMPETITION EC1
  where EC1.PARENTCOMPETITIONID = EC.COMPETITIONID
  and not EC1.CONCOURSID is null
) as HAS_CHILD_CONCOURSES,

 (
  select GS.TITLE
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_TREE GS
  on GS.NODEID = EC1.SPECIALITYID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and (   (
                         select EC2.SPECIALITYID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = EC.PARENTCOMPETITIONID) is null )
  ) as SPECIALITY,

  (
  select GE.TITLE
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_TREE GE
  on GE.NODEID = EC1.EDUFORMID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.EDUFORMID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = EC.PARENTCOMPETITIONID) is null )
  ) as EDUFORM ,

  (
  select GR.TITLE
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_TREE GR
  on GR.NODEID = EC1.RECRUITINGID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.RECRUITINGID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = EC.PARENTCOMPETITIONID) is null )
  ) as RECRUITING,


  (
  select GED.TITLE
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_TREE GED
  on GED.NODEID = EC1.EDUBASISID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.EDUBASISID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = EC.PARENTCOMPETITIONID) is null )
  ) as EDUBASIS,

  (
  select GC.TITLE
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_TREE GC
  on GC.NODEID = EC1.COUNTRYTYPEID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.COUNTRYTYPEID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = EC.PARENTCOMPETITIONID) is null )
  ) as COUNTRYTYPE,
 (
  select first 1 1
  from ENTRANCE_COMPETITION EC1
  where EC1.COMPETITIONID = EC.COMPETITIONID
  and not EC1.CONCOURSID is null
) as HAS_CONCOURSES

from ENTRANCE_COMPETITION EC
where EC.COMPETITIONID = :COMPETITIONID