select EC.COMPETITIONID, EC.EDUBASISID,
 (
  select GS.SPECIALITY
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_SPECIALITY GS
  on GS.SPECIALITYID = EC1.SPECIALITYID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and (   (
                         select EC2.SPECIALITYID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = :COMPETITIONID) is null )
  ) as SPECIALITY,

  (
  select GE.EDUFORM
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_EDUFORM GE
  on GE.EDUFORMID = EC1.EDUFORMID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.EDUFORMID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = :COMPETITIONID) is null )
  ) as EDUFORM ,

  (
  select GR.RECRUITING
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_RECRUITING GR
  on GR.RECRUITINGID = EC1.RECRUITINGID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.RECRUITINGID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = :COMPETITIONID) is null )
  ) as RECRUITING,


  (
  select GED.EDUBASIS
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_EDUBASIS GED
  on GED.EDUBASISID = EC1.EDUBASISID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.EDUBASISID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = :COMPETITIONID) is null )
  ) as EDUBASIS,

  (
  select GC.COUNTRYTYPE
  from ENTRANCE_COMPETITION EC1
  inner join GUIDE_COUNTRYTYPE GC
  on GC.COUNTRYTYPEID = EC1.COUNTRYTYPEID
  where EC1.COMPETITIONID = EC.COMPETITIONID
        and ( (
                         select EC2.COUNTRYTYPEID
                         from ENTRANCE_COMPETITION EC2
                         where EC2.COMPETITIONID = :COMPETITIONID) is null )
  ) as COUNTRYTYPE,
 (
  select first 1 1
  from ENTRANCE_COMPETITION EC1
  where EC1.competitionid = EC.COMPETITIONID
  and not EC1.CONCOURSID is null
) as HAS_CONCOURSES

from ENTRANCE_COMPETITION EC
where EC.PARENTCOMPETITIONID = :COMPETITIONID
      and EC.CONCOURSID = 1