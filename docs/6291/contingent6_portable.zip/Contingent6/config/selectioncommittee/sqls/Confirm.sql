execute block (ORDERID bigint = ?ORDERID,
    PARTITIONID integer = ?PARTITIONID,
    BEGINDATE date = ?EnterDate,
    SPECIALITYID integer = ?Speciality,
    DEPARTMENTID integer = ?Department,
    EDUBASISID integer = ?EduBasis,
    EDUFORMID integer = ?EduForm,
    EDUTERM float = ?EduTerm,
    SEMESTER smallint = ?Semester,
    EDUYEAR smallint = ?EduYear)
as
declare variable PERSONID bigint;
declare variable ENTRANTDOCID bigint;
declare variable COMPETITIONACCOUNTID bigint;
begin
   for select PERSONID
      from PARTITIONSTOPERSONS
      where PARTITIONID = :PARTITIONID
      into :PERSONID
  do
  begin
    if (not (
         SPECIALITYID is null
         and DEPARTMENTID is null
         and EDUBASISID is null
         and EDUFORMID is null
         and EDUTERM is null
         and SEMESTER is null
         and EDUYEAR is null
       )) then
    begin

       select c2e.ENTRANT_DOCID
           from CA2ENTRANT c2e
           inner join COMPETITION_ACCOUNT ca
           on ca.COMPETITIONACCOUNTID = c2e.COMPETITIONACCOUNTID
           inner join ENTRANCE_COMPETITION ec
           on ec.COMPETITIONID = ca.COMPETITIONID
           inner join ENTRANT_DOCS ed
           on ed.ENTRANT_DOCID = c2e.ENTRANT_DOCID
           where ed.PERSONID = :PERSONID
                 and EC.ENTERYEAR = :EDUYEAR
                 and EC.EDUFORMID = :EDUFORMID
                 and EC.EDUBASISID = :EDUBASISID
                 and EC.SPECIALITYID = :SPECIALITYID
                 and not EC.CONCOURSID is null
                 and CA.CALCCOMPETITIONACCOUNTID = (
                                                    select first 1 CA1.CALCCOMPETITIONACCOUNTID
                                                    from COMPETITION_ACCOUNT CA1
                                                    where CA1.COMPETITIONID = CA.COMPETITIONID
                                                    order by CA1.ACCOUNTTIME desc
                                                  )
                 and C2E.ACCEPTEE = 1
       into :ENTRANTDOCID;

      select c2e.COMPETITIONACCOUNTID
           from CA2ENTRANT c2e
           inner join COMPETITION_ACCOUNT ca
           on ca.COMPETITIONACCOUNTID = c2e.COMPETITIONACCOUNTID
           inner join ENTRANCE_COMPETITION ec
           on ec.COMPETITIONID = ca.COMPETITIONID
           inner join ENTRANT_DOCS ed
           on ed.ENTRANT_DOCID = c2e.ENTRANT_DOCID
           where ed.PERSONID = :PERSONID
                 and EC.ENTERYEAR = :EDUYEAR
                 and EC.EDUFORMID = :EDUFORMID
                 and EC.EDUBASISID = :EDUBASISID
                 and EC.SPECIALITYID = :SPECIALITYID
                 and not EC.CONCOURSID is null
                 and CA.CALCCOMPETITIONACCOUNTID = (
                                                    select first 1 CA1.CALCCOMPETITIONACCOUNTID
                                                    from COMPETITION_ACCOUNT CA1
                                                    where CA1.COMPETITIONID = CA.COMPETITIONID
                                                    order by CA1.ACCOUNTTIME desc
                                                  )
                 and C2E.ACCEPTEE = 1
      into :COMPETITIONACCOUNTID;

--      insert into HS_MOVEMENT(PERSONID, ORDERID, BEGINDATE, SPECIALITYID, DEPARTMENTID, EDUBASISID, EDUFORMID, EDUTERM, SEMESTER, EDUYEAR, STATUS, ENTRANT_DOCID, COMPETITIONACCOUNTID)
--      values (:PERSONID, :ORDERID, :BEGINDATE, :SPECIALITYID, :DEPARTMENTID, :EDUBASISID, :EDUFORMID, :EDUTERM, :SEMESTER, :EDUYEAR, '�', :ENTRANTDOCID, :COMPETITIONACCOUNTID);

--    insert into INFO_STUDENTS(PERSONID, SPECIALITYID, EDUFORMID, EDUBASISID, EDUTERM, DEPARTMENTID, SEMESTER, EDUYEAR)
--      values (:PERSONID, :SPECIALITYID, :EDUFORMID, :EDUBASISID, :EDUTERM, :DEPARTMENTID, :SEMESTER, :EDUYEAR);
    
      update PERSONS p
      set p.ENTRANT_DOCID = :ENTRANTDOCID,
          p.COMPETITIONACCOUNTID = :COMPETITIONACCOUNTID
           where PERSONID = :PERSONID;



      

--      delete from HS_MOVEMENT_FULL where PERSONID = :PERSONID;
  
--      execute procedure SP_PERSONMOVEMENT_CALC(:PERSONID);
  
--      execute procedure SP_PERSONLASTMOVEMENT_CALC(:PERSONID);
    end


   end
end