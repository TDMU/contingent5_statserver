with recursive
  FIELDS AS
  (
    select GT.NODEID, GT.TITLE,
      (
        select GF.FIELDNAME
        from V_GUIDE_VALUES VGVR
        inner join GUIDE_FIELDS GF
        on (GF.NODEID = VGVR.VALUEREF)
        where (VGVR.NODEID = GT.NODEID)
      ) as FIELDNAME,
      decode(GT.TYPE_NODE_KEY, 'T_FIELDS_PAGE', 0, 'T_FIELDS_SECTION', 1, 2) as NODELEVEL,
      cast(lpad(GT.SORTORDER, 2, '0') as varchar(100)) as SORT_KEY,
      coalesce(
        (
          select VGV.VALUESTR500
          from V_GUIDE_VALUES VGV
          where VGV.NODEID = GT.NODEID
          and VGV.FIELDNAME = 'FIELD_DETAILS'
        ),
        (
          select GF.EDITOR_INFO
          from V_GUIDE_VALUES VGVR
          inner join GUIDE_FIELDS GF
          on (GF.NODEID = VGVR.VALUEREF)
          where (VGVR.NODEID = GT.NODEID)
        )
      ) as FIELD_DETAILS
    from V_GUIDE_TREE GT
    where GT.PARENTID = :CARD_NODEID
    and GT.USE = 1

    union all

    select GT.NODEID, GT.TITLE,
      (
        select GF.FIELDNAME
        from V_GUIDE_VALUES VGVR
        inner join GUIDE_FIELDS GF
        on (GF.NODEID = VGVR.VALUEREF)
        where (VGVR.NODEID = GT.NODEID)
      ) as FIELDNAME,
      decode(GT.TYPE_NODE_KEY, 'T_FIELDS_PAGE', 0, 'T_FIELDS_SECTION', 1, 2) as NODELEVEL,
      F.SORT_KEY || lpad(GT.SORTORDER, 2, '0') || GT.SORTORDER as SORT_KEY,
      coalesce(
        (
          select VGV.VALUESTR500
          from V_GUIDE_VALUES VGV
          where VGV.NODEID = GT.NODEID
          and VGV.FIELDNAME = 'FIELD_DETAILS'
        ),
        (
          select GF.EDITOR_INFO
          from V_GUIDE_VALUES VGVR
          inner join GUIDE_FIELDS GF
          on (GF.NODEID = VGVR.VALUEREF)
          where (VGVR.NODEID = GT.NODEID)
        )
      ) as FIELD_DETAILS
    from V_GUIDE_TREE GT
    inner join FIELDS F
    on GT.PARENTID = F.NODEID
    where GT.USE = 1
  )
select F.NODEID, F.NODELEVEL, F.TITLE, F.FIELDNAME, F.FIELD_DETAILS
from FIELDS F
order by F.SORT_KEY