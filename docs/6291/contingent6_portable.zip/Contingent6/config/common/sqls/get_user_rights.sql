select coalesce(upper(GA.ACTIONNAME), 'act_' || GA.NODEID) as ACTIONNAME, 
  coalesce(
    (
      with recursive
        USERSGROUPS AS
        (
          select GT.NODEID as USERID, GT.PARENTID, GT.TITLE
          from GUIDE_TREE GT
          where GT.NODEID = :USERID

          union all
      
          select VGT.NODEID, VGT.PARENTID, VGT.TITLE
          from V_GUIDE_TREE VGT
          inner join USERSGROUPS UGS
          on VGT.NODEID = UGS.PARENTID
        )
      select first 1 SUR.RIGHT_STATE
      from USERSGROUPS UGS
      inner join SEC_USER_RIGHTS SUR
      on (SUR.USERID = UGS.USERID)
      where SUR.ACTIONID = GA.NODEID
    ), 0
  ) as RIGHT_STATE
from GUIDE_TREE GT
inner join GUIDE_ACTIONS GA
on (GA.NODEID = GT.NODEID)
where GT.PATH starting with (
  select GT.FULLPATH
  from GUIDE_TREE GT
  where GT.NODE_KEY = 'CONF_' || upper(current_role)
)
and (GT.USE = 1)
and (GA.LIMITEDBYRIGHTS = 1)