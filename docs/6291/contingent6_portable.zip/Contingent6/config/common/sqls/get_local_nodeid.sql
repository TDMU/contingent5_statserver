select GT.NODEID
from GUIDE_TREE GT
where GT.PATH starting with (
  select GT_CONF.FULLPATH
  from GUIDE_TREE GT_CONF
  where GT_CONF.NODE_KEY = 'CONF_' || current_role
)
and GT.LOCAL_KEY = 'MODULE_PCARD'