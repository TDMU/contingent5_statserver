execute block (JOINIDS D$VARCHAR500 = :JOINIDS)
returns (
  JOINS D$VARCHAR20000
)
as
declare variable CUR_JOIN D$VARCHAR5000;
declare variable JOINID D$INTEGER;
begin
  JOINS = '';
  for select WORD_STR from WORD_LIST(:JOINIDS)
      into :JOINID
  do
  begin
    CUR_JOIN = null;
    
    select VGV.VALUESTR500
    from V_GUIDE_VALUES VGV
    where VGV.NODEID = :JOINID
    and VGV.FIELDNAME = 'JOIN_SQL'
    into CUR_JOIN;

    if (not CUR_JOIN is null) then
      JOINS = JOINS || ascii_char(13) || CUR_JOIN;
  end

  suspend;
end